const KEY="fit_food_v1";
const state=JSON.parse(localStorage.getItem(KEY)||'{"recipes":[],"workouts":[]}');
const $=s=>document.querySelector(s);
const esc=s=>String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[c]));
function save(){localStorage.setItem(KEY,JSON.stringify(state));render()}
function id(){return Date.now()+Math.random().toString(16).slice(2)}
function toast(t){const e=$("#toast");e.textContent=t;e.classList.add("show");setTimeout(()=>e.classList.remove("show"),1800)}
function openModal(title,html){$("#modalTitle").textContent=title;$("#modalBody").innerHTML=html;$("#modal").classList.remove("hidden")}
function closeModal(){$("#modal").classList.add("hidden")}
$("#closeModal").onclick=closeModal;
$("#modal").addEventListener("click",e=>{if(e.target.id==="modal")closeModal()});

document.querySelectorAll(".tab").forEach(b=>b.onclick=()=>{document.querySelectorAll(".tab").forEach(x=>x.classList.remove("active"));document.querySelectorAll(".view").forEach(x=>x.classList.remove("active"));b.classList.add("active");$("#"+b.dataset.tab).classList.add("active")});
document.querySelector("[data-add-recipe]").onclick=()=>recipeForm();
document.querySelector("[data-add-workout]").onclick=()=>workoutForm();
$("#recipeSearch").oninput=render;

function render(){
 const q=$("#recipeSearch").value.toLowerCase();
 const rs=state.recipes.filter(r=>(r.title+" "+r.category+" "+r.ingredients).toLowerCase().includes(q));
 $("#recipeList").innerHTML=rs.length?rs.map(r=>`
 <article class="card"><h3>${esc(r.favorite?"♥ ":"")}${esc(r.title)}</h3>
 <div class="meta">${esc(r.category)} · ${r.minutes||0} Min. · ${r.servings||1} Portionen</div>
 <div class="desc">${esc(r.description||"Keine Beschreibung")}</div>
 <div class="card-actions"><button class="secondary" onclick="recipeForm('${r.id}')">Bearbeiten</button><button class="danger" onclick="deleteRecipe('${r.id}')">Löschen</button></div></article>`).join(""):`<div class="empty">Noch keine Rezepte gespeichert.<br><br><button class="primary" onclick="recipeForm()">Erstes Rezept hinzufügen</button></div>`;

 $("#workoutList").innerHTML=state.workouts.length?state.workouts.map(w=>`
 <article class="card"><h3>${esc(w.name)}</h3><div class="meta">${w.exercises.length} Übungen</div><div class="desc">${esc(w.description||"Keine Beschreibung")}</div>
 <div>${w.exercises.map(e=>`<div class="exercise"><h4>${esc(e.name)}</h4><div class="meta">${e.sets} Sätze × ${e.reps} · ${e.weight} kg · ${e.rest}s Pause</div>${e.notes?`<div class="desc">${esc(e.notes)}</div>`:""}</div>`).join("")}</div>
 <div class="card-actions"><button class="secondary" onclick="workoutForm('${w.id}')">Bearbeiten</button><button class="danger" onclick="deleteWorkout('${w.id}')">Löschen</button></div></article>`).join(""):`<div class="empty">Noch keine Trainingspläne gespeichert.<br><br><button class="primary" onclick="workoutForm()">Ersten Plan hinzufügen</button></div>`;
}
function recipeForm(rid){
 const r=state.recipes.find(x=>x.id===rid)||{};
 openModal(rid?"Rezept bearbeiten":"Neues Rezept",`<form id="recipeForm" class="form">
 <div class="field"><label>Name</label><input id="rTitle" required value="${esc(r.title)}"></div>
 <div class="field"><label>Beschreibung</label><input id="rDesc" value="${esc(r.description)}"></div>
 <div class="row"><div class="field"><label>Portionen</label><input id="rServ" type="number" min="1" value="${r.servings||1}"></div><div class="field"><label>Minuten</label><input id="rMin" type="number" min="0" value="${r.minutes||0}"></div></div>
 <div class="field"><label>Kategorie</label><input id="rCat" value="${esc(r.category||"Sonstiges")}"></div>
 <div class="field"><label>Zutaten</label><textarea id="rIng" placeholder="Eine Zutat pro Zeile">${esc(r.ingredients)}</textarea></div>
 <div class="field"><label>Zubereitung</label><textarea id="rIns">${esc(r.instructions)}</textarea></div>
 <label class="check"><input id="rFav" type="checkbox" ${r.favorite?"checked":""}> Favorit</label>
 <button class="primary">Speichern</button></form>`);
 $("#recipeForm").onsubmit=e=>{e.preventDefault();const x={id:rid||id(),title:$("#rTitle").value.trim(),description:$("#rDesc").value.trim(),servings:+$("#rServ").value||1,minutes:+$("#rMin").value||0,category:$("#rCat").value.trim()||"Sonstiges",ingredients:$("#rIng").value.trim(),instructions:$("#rIns").value.trim(),favorite:$("#rFav").checked};const i=state.recipes.findIndex(a=>a.id===x.id);i<0?state.recipes.push(x):state.recipes[i]=x;save();closeModal();toast("Rezept gespeichert")};
}
function deleteRecipe(rid){if(confirm("Rezept wirklich löschen?")){state.recipes=state.recipes.filter(x=>x.id!==rid);save();toast("Rezept gelöscht")}}
function workoutForm(wid){
 const w=state.workouts.find(x=>x.id===wid)||{id:wid||id(),name:"",description:"",exercises:[]};
 openModal(wid?"Trainingsplan bearbeiten":"Neuer Trainingsplan",`<form id="workoutForm" class="form">
 <div class="field"><label>Name</label><input id="wName" required value="${esc(w.name)}"></div>
 <div class="field"><label>Beschreibung</label><input id="wDesc" value="${esc(w.description)}"></div>
 <div><label style="font-size:12px;font-weight:700;color:#687168">Übungen</label><div id="exerciseEditor">${w.exercises.map((e,i)=>exerciseHtml(e,i)).join("")}</div></div>
 <button type="button" class="secondary" id="addExercise">+ Übung</button><button class="primary">Speichern</button></form>`);
 $("#addExercise").onclick=()=>{const box=$("#exerciseEditor");box.insertAdjacentHTML("beforeend",exerciseHtml({},box.children.length))};
 $("#workoutForm").onsubmit=e=>{e.preventDefault();const exercises=[...document.querySelectorAll(".exercise-editor")].map(el=>({name:el.querySelector(".en").value.trim(),sets:+el.querySelector(".es").value||3,reps:+el.querySelector(".er").value||10,weight:+el.querySelector(".ew").value||0,rest:+el.querySelector(".ep").value||90,notes:el.querySelector(".eo").value.trim()})).filter(x=>x.name);const x={id:w.id,name:$("#wName").value.trim(),description:$("#wDesc").value.trim(),exercises};const i=state.workouts.findIndex(a=>a.id===x.id);i<0?state.workouts.push(x):state.workouts[i]=x;save();closeModal();toast("Trainingsplan gespeichert")};
}
function exerciseHtml(e={}){return `<div class="exercise exercise-editor"><div class="field"><label>Übung</label><input class="en" value="${esc(e.name)}" placeholder="z.B. Bankdrücken"></div><div class="row"><div class="field"><label>Sätze</label><input class="es" type="number" value="${e.sets||3}"></div><div class="field"><label>Wiederholungen</label><input class="er" type="number" value="${e.reps||10}"></div></div><div class="row"><div class="field"><label>Gewicht kg</label><input class="ew" type="number" step="0.5" value="${e.weight||0}"></div><div class="field"><label>Pause Sek.</label><input class="ep" type="number" value="${e.rest||90}"></div></div><div class="field"><label>Notizen</label><input class="eo" value="${esc(e.notes)}"></div></div>`}
function deleteWorkout(wid){if(confirm("Trainingsplan wirklich löschen?")){state.workouts=state.workouts.filter(x=>x.id!==wid);save();toast("Trainingsplan gelöscht")}}
$("#installHelp").onclick=()=>openModal("Auf dem iPhone installieren",`<div class="desc" style="line-height:1.7"><b>1.</b> Öffne diese Website in Safari.<br><b>2.</b> Tippe unten/oben auf <b>Teilen</b> (□↑).<br><b>3.</b> Wähle <b>Zum Home-Bildschirm</b>.<br><b>4.</b> Tippe auf <b>Hinzufügen</b>.<br><br>Danach erscheint Fit & Food wie eine App auf deinem Home-Bildschirm.</div>`);
render();

if ("serviceWorker" in navigator) window.addEventListener("load",()=>navigator.serviceWorker.register("./sw.js").catch(()=>{}));
