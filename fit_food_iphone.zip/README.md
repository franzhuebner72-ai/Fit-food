# Fit & Food – iPhone-Version

Diese Version ist eine statische Web-App/PWA. Sie benötigt keinen Server und speichert die Daten im Browser des iPhones über localStorage.

## Funktionen
- Rezepte speichern, bearbeiten, löschen und suchen
- Favoriten
- Trainingspläne speichern
- Übungen mit Sätzen, Wiederholungen, Gewicht und Pause
- Installation auf dem iPhone über Safari → Teilen → Zum Home-Bildschirm

## Wichtig
Die Dateien müssen über HTTPS bereitgestellt werden, damit Service Worker/PWA-Funktionen zuverlässig funktionieren. Für einen schnellen Test reicht auch eine normale statische Website; die Daten werden lokal im Browser gespeichert.

## Geeignete kostenlose Hosting-Dienste
- GitHub Pages
- Netlify
- Vercel

Nach dem Hochladen von `index.html`, `style.css`, `app.js`, `manifest.json`, `sw.js` und `icon.svg` die Website-URL in Safari öffnen.

